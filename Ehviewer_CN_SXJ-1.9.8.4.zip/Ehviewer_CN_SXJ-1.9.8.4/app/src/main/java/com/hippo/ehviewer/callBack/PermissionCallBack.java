package com.hippo.ehviewer.callBack;

public interface PermissionCallBack {
    void agree(int permissionCode);

}
