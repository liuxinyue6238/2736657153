package com.hippo.ehviewer.widget;

import android.content.Context;
import android.util.AttributeSet;

import com.hippo.easyrecyclerview.EasyRecyclerView;

public class MyEasyRecyclerView extends EasyRecyclerView {
    public MyEasyRecyclerView(Context context) {
        super(context);
    }

    public MyEasyRecyclerView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public MyEasyRecyclerView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
    }


}
