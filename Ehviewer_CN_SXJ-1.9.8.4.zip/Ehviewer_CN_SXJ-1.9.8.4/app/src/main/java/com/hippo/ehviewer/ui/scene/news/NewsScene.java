package com.hippo.ehviewer.ui.scene.news;

public class NewsScene {
}
