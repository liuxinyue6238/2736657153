package com.hippo.ehviewer.client.data;

public class ArchiverData {
    public String funds;
    public String originalCost;
    public String originalSize;
    public String originalUrl;
    public String resampleCost;
    public String resampleSize;
    public String resampleUrl;
    public ArchiverData(){}
}
