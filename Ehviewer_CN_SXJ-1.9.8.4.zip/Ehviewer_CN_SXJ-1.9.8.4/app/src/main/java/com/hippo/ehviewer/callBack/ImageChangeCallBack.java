package com.hippo.ehviewer.callBack;

import java.io.File;

public interface ImageChangeCallBack {
    void backgroundSourceChange(File file);
}
