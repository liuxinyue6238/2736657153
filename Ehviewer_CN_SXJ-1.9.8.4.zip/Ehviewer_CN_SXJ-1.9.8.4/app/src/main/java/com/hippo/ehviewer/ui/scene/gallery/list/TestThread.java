package com.hippo.ehviewer.ui.scene.gallery.list;

public class TestThread extends Thread{

    @Override
    public synchronized void start() {
        super.start();

    }

    @Override
    public void run() {
        super.run();
    }


}
