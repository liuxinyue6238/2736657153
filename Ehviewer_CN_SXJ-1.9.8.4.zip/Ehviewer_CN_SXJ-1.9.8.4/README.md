# [感谢名单](https://github.com/xiaojieonly/Ehviewer_CN_SXJ/blob/BiLi_PC_Gamer/feedauthor/thankyou.md) 
# [常见问题汇总](https://github.com/xiaojieonly/Ehviewer_CN_SXJ/blob/BiLi_PC_Gamer/feedauthor/EhviewerIssue.md)

# 2024/07/01 :     
 ###  新版发布1.9.8.2（如果出现问题请覆盖安装旧版本）   
 ###  修复历史记录需要重新设置才能显示的问题   
 ###  新增图片请求链接校验，以防止在h@h服务器被不法分子劫持后导致的涉政、涉毒、涉赌及邪教等极端或影响E站及APP稳定性的内容的出现   
 ###  下载列表添加随机浏览功能   
 ###  改善收藏按鈕   
 ###  新增图片搜索上传地址host   
 ###  图片搜索优化   
 ###  历史记录默认值从0修改为100,去除无上限选项，为了流畅度考虑，现在的历史记录上限为20000   
 ###  新增下载超时时间设置，用于设置每张图片的最大下载时限，默认不设限，可在'设置-下载'内进行设置   
 ###  新增下载速度归零超时放弃功能，现在下载速度为0超过30秒会主动放弃当前下载的图片   
 ###  浏览画廊图片时，为阅读进度文本添加黑色描边   
   点击前往下载：[Microsoft App Center](install.appcenter.ms/users/xiaojieonly/apps/com.xjs.ehviewer/distribution_groups/let's%20roll)

[//]: # (   点击前往下载：[EhViewer &#40;20.8 MB&#41;]&#40;https://appteka.store/app/ec4r177414&#41;   )
   点击前往下载：[百度云](https://pan.baidu.com/s/16IG6TFYTfZyirYFlheyDlQ)  密码:il35   
   点击前往下载（电脑端可正常下载）：[蓝奏云](https://wwb.lanzouj.com/iIwtX238nuif)  密码:dq01   
   点击前往下载：[github](https://github.com/xiaojieonly/Ehviewer_CN_SXJ/releases)    
   点击前往赏饭：[要饭嘛不寒掺](https://github.com/xiaojieonly/Ehviewer_CN_SXJ/blob/BiLi_PC_Gamer/feedauthor/support.md)    
   Torrent链接：magnet:?xt=urn:btih:d3ea86412c891bdf7b3e1c98866acbb658dcdfe4&dn=EhViewer-1.9.8.2.apk    
   Telegram群:https://t.me/+WyclP8pPlk-JfbwS    
   Telegram通知群:https://t.me/Ehviewer_xiaojieonly_channel    

# 2024/06/01 :  祝大家儿童节快乐~~~
 ###  新版发布1.9.8.1（如果出现问题请覆盖安装旧版本）   
 ###  优化了原图下载逻辑   
 ###  新增雲端收藏隨機挑本功能   
 ###  新增云端收藏当前数据随机挑选功能   
 ###  新增画廊列表当前数据随机挑选功能   
   点击前往下载：[Microsoft App Center](install.appcenter.ms/users/xiaojieonly/apps/com.xjs.ehviewer/distribution_groups/let's%20roll)   
   点击前往下载：[EhViewer (20.8 MB)](https://appteka.store/app/ec4r177414)   
   点击前往下载：[百度云](https://pan.baidu.com/s/1cJ-h0fXcs9j8ChZOIDQcow)  密码:zr7m   
   点击前往下载（电脑端可正常下载）：[蓝奏云](https://wwb.lanzouj.com/iFmqD20gj3kb)  密码:d2ou   
   点击前往下载：[github](https://github.com/xiaojieonly/Ehviewer_CN_SXJ/releases)    
   点击前往赏饭：[要饭嘛不寒掺](https://github.com/xiaojieonly/Ehviewer_CN_SXJ/blob/BiLi_PC_Gamer/feedauthor/support.md)    
   Torrent链接：magnet:?xt=urn:btih:a86fba060d36f9cc3e602daa0320a067d56c3f48&dn=EhViewer-1.9.8.1.apk  
   Telegram群:https://t.me/+WyclP8pPlk-JfbwS    
   Telegram通知群:https://t.me/Ehviewer_xiaojieonly_channel

# 2024/05/01 :  劳动节快乐~~~
 ###  新版发布1.9.8.0（如果出现问题请覆盖安装旧版本）   
 ###  重新添加图片搜索功能   
 ###  画廊排行榜优化，现在可以跳转至详细画廊排行列表   
 ###  修复url打开奔溃问题   
 ###  修复了一些可能的奔溃问题   
   点击前往下载：[Microsoft App Center](install.appcenter.ms/users/xiaojieonly/apps/com.xjs.ehviewer/distribution_groups/let's%20roll)   
   点击前往下载：[百度云](https://pan.baidu.com/s/1gtjGTkJfRp0UT-klghLG-Q)  密码:goe2   
   点击前往下载（电脑端可正常下载）：[蓝奏云](https://wwb.lanzouj.com/iM1W51x6fupg)  密码:92a6   
   点击前往下载：[github](https://github.com/xiaojieonly/Ehviewer_CN_SXJ/releases)    
   点击前往赏饭：[要饭嘛不寒掺](https://github.com/xiaojieonly/Ehviewer_CN_SXJ/blob/BiLi_PC_Gamer/feedauthor/support.md)    
   Torrent链接：magnet:?xt=urn:btih:0e14bd3e5d8ff3d3096aadceecdcdbf322567053&dn=EhViewer-1.9.8.0.apk  
   Telegram群:https://t.me/+WyclP8pPlk-JfbwS    
   Telegram通知群:https://t.me/Ehviewer_xiaojieonly_channel

# 2024/04/17 :  host过期，紧急修复   
 ###  新版发布1.9.7.11（如果出现问题请覆盖安装1.9.7.7版本）   
 ###  修复档案下载在捐赠用户浏览站点为里站时不起作用的问题   
 ###  修复过期host   
   点击前往下载：[Microsoft App Center](install.appcenter.ms/users/xiaojieonly/apps/com.xjs.ehviewer/distribution_groups/let's%20roll)   
   点击前往下载：[百度云](https://pan.baidu.com/s/1RctX2kaupkGFWG8XAZA0_Q)  密码:5333   
   点击前往下载（电脑端可正常下载）：[蓝奏云](https://wwb.lanzouj.com/i8Pfs1vh2med)  密码:f27s   
   点击前往下载：[github](https://github.com/xiaojieonly/Ehviewer_CN_SXJ/releases)    
   点击前往赏饭：[要饭嘛不寒掺](https://github.com/xiaojieonly/Ehviewer_CN_SXJ/blob/BiLi_PC_Gamer/feedauthor/support.md)    
   Torrent链接：magnet:?xt=urn:btih:e0459ba93edb0e942c13b89c917974374ef5bc99&dn=EhViewer-1.9.7.11.apk    
   Telegram群:https://t.me/+WyclP8pPlk-JfbwS    
   Telegram通知群:https://t.me/Ehviewer_xiaojieonly_channel   

# 2024/04/05 :    
 ###  新版发布1.9.7.10（如果出现问题请覆盖安装1.9.7.7版本）   
 ###  修复归档下载因下载链接为空时导致的奔溃问题   
 ###  修复wifi迁移时因获取不到ip导致的奔溃问题   
 ###  修复从剪切版导入cookie时格式不对导致的奔溃问题   
 ###  修复获取Tag列表时导致的奔溃问题   
 ###  修复设置-Eh-显示标签翻译修改时奔溃的问题   
 ###  修复历史记录无法显示的问题   
   点击前往下载：[Microsoft App Center](install.appcenter.ms/users/xiaojieonly/apps/com.xjs.ehviewer/distribution_groups/let's%20roll)   
   点击前往下载：[百度云](https://pan.baidu.com/s/1mP9f6FPsELJLy-UiJvNzLQ)  密码:ohj2   
   点击前往下载（电脑端可正常下载）：[蓝奏云](https://wwb.lanzouj.com/iC4AM1tzaf4f)  密码:cco8   
   点击前往下载：[github](https://github.com/xiaojieonly/Ehviewer_CN_SXJ/releases)    
   点击前往赏饭：[要饭嘛不寒掺](https://github.com/xiaojieonly/Ehviewer_CN_SXJ/blob/BiLi_PC_Gamer/feedauthor/support.md)    
   Torrent链接：magnet:?xt=urn:btih:3904faf25e291f70754f087aaa9729704fa588f7&dn=EhViewer-1.9.7.10.apk    
   Telegram群:https://t.me/+WyclP8pPlk-JfbwS    
   Telegram通知群:https://t.me/Ehviewer_xiaojieonly_channel

# 2024/04/01 : 愚人节快乐~今天你骗人了吗🤣    
 ###  新版发布1.9.7.8（如果出现问题请覆盖安装上一版本）    
 ###  修复画廊列表标签弹窗在特定情况下没能正确消失的问题    
 ###  修复导入数据量过大导致的主线程奔溃问题，优化数据导入流程，同步导入改为异步导入    
 ###  移除远古更新代码    
 ###  更新Tag汉化链接    
 ###  历史记录不再限制为100条，可以在设置-EH-历史记录数量中自行设置    
 ###  新增档案下载功能    
 ###  新增在未退出app情况下档案下载完成后自动导入到下载列表   
 ###  修复画廊下载失败时画廊详情中显示为更新的问题
 ###  更新依赖，规避反序列化、Xss漏洞
 ###  由于微软政策原因将错误收集模块从Visual Studio App Center迁移至Google Firebase
 ###  隐藏已经不再支持的图片搜索功能
   点击前往下载：[Microsoft App Center](install.appcenter.ms/users/xiaojieonly/apps/com.xjs.ehviewer/distribution_groups/let's%20roll)   
   点击前往下载：[百度云](https://pan.baidu.com/s/18_AeVXxBTdaRnwU4cQwvbA)  密码:yi1m   
   点击前往下载（电脑端可正常下载）：[蓝奏云](https://wwb.lanzouj.com/ie7PI1tgrnwj)  密码:egy6   
   点击前往下载：[github](https://github.com/xiaojieonly/Ehviewer_CN_SXJ/releases)    
   点击前往赏饭：[要饭嘛不寒掺](https://github.com/xiaojieonly/Ehviewer_CN_SXJ/blob/BiLi_PC_Gamer/feedauthor/support.md)    
   Torrent链接：magnet:?xt=urn:btih:76a0eff70fc84e26d7e97710d38b904c4ed8e53a&dn=EhViewer-1.9.7.8.apk    
   Telegram群:https://t.me/+WyclP8pPlk-JfbwS    
   Telegram通知群:https://t.me/Ehviewer_xiaojieonly_channel

# 2024/03/02 :    
 ###  新版发布1.9.7.7（如果出现问题请覆盖安装上一版本）     
 ###  wifi数据迁移时因空指针导致的奔溃问题    
 ###  下载列表分页优化，现在在列表中进入详情页后返回，列表会停留在原位    
 ###  修复画廊下载失败时画廊详情中显示为更新的问题    
 ###  优化wifi迁移时的稳定性       
 ###  使用cookie登录时从剪切板导入的功能（cookie格式需与导出格式一致）    
 ###  更新流程优化，允许用户选择下载为新画廊或者覆盖下载      
   点击前往下载：[Microsoft App Center](install.appcenter.ms/users/xiaojieonly/apps/com.xjs.ehviewer/distribution_groups/let's%20roll)   
   点击前往下载：[百度云](https://pan.baidu.com/s/1l3R-dzXgFJZmXIW-FXxAww)  密码:sm0x   
   点击前往下载（电脑端可正常下载）：[蓝奏云](https://wwb.lanzouj.com/ipEmU1pz9vif)  密码:fv77   
   点击前往下载：[github](https://github.com/xiaojieonly/Ehviewer_CN_SXJ/releases)    
   点击前往赏饭：[要饭嘛不寒掺](https://github.com/xiaojieonly/Ehviewer_CN_SXJ/blob/BiLi_PC_Gamer/feedauthor/support.md)    
   Torrent链接：magnet:?xt=urn:btih:7886b13e3eeb7e9a633ea61e1faa7b01b4bb5888&dn=EhviewerAllVersions  
   Telegram群:https://t.me/+WyclP8pPlk-JfbwS    
   Telegram通知群:https://t.me/Ehviewer_xiaojieonly_channel  

# 2024/02/03 :感谢大伙们的陪伴，提前祝大家春节快乐~    
 ###  新版发布1.9.7.6（更新较多，如果出现问题请回滚至上一版本）     
 ###  更新了新的安全DNS    
 ###  修复了因缓存数据导致不下载原图的问题    
 ###  修复了.ehviewer 文件不生成的问题    
 ###  修复wifi数据迁移功能因权限不足导致的奔溃       
 ###  修复一个自动阅读导致的崩溃问题    
 ###  修复Github CL检查    
 ###  新增保持书签侧边栏列表滚动位置功能    
 ###  新增下载列表翻页，当列表画廊数大于500时生效    
 ###  日本語の更新やったよ。眠いです    
   点击前往下载：[Microsoft App Center](https://install.appcenter.ms/users/xiaojieonly/apps/com.xjs.ehviewer/distribution_groups/let's%20roll)   
   点击前往下载：[百度云](https://pan.baidu.com/s/1V6QPhhdiU1rRxnZQbYUIHA)  密码:6ird   
   点击前往下载（电脑端可正常下载）：[蓝奏云](https://wwb.lanzouj.com/i2MH01n6e2he)  密码:e91v   
   点击前往下载：[github](https://github.com/xiaojieonly/Ehviewer_CN_SXJ/releases)    
   点击前往赏饭：[要饭嘛不寒掺](https://github.com/xiaojieonly/Ehviewer_CN_SXJ/blob/BiLi_PC_Gamer/feedauthor/support.md)    
   Torrent链接：magnet:?xt=urn:btih:0855b9440fb270c77d3ca08bc02375800e587990  
   Telegram群:https://t.me/+WyclP8pPlk-JfbwS    
   Telegram通知群:https://t.me/Ehviewer_xiaojieonly_channel  

# 2024/01/01 :感谢大家在过去一年的陪伴，祝大家新年快乐~    
 ###  新版发布1.9.7.2     
 ###  新增自动翻页功能    
 ###  新增画廊详情页标题点击复制功能    
 ###  为EH->EHentai 设置页面添加直连适配       
 ###  修复跳转画廊新版本时闪退的问题    
   点击前往下载：[Microsoft App Center](https://install.appcenter.ms/users/xiaojieonly/apps/com.xjs.ehviewer/distribution_groups/let's%20roll)   
   点击前往下载：[百度云](https://pan.baidu.com/s/1PmH59LkFXIwObWoEmnp1IQ)  密码:ffk4   
   点击前往下载（电脑端可正常下载）：[蓝奏云](https://wwsu.lanzouj.com/iOCCu1jioj9g)  密码:1az8   
   点击前往下载：[github](https://github.com/xiaojieonly/Ehviewer_CN_SXJ/releases)    
   点击前往赏饭：[要饭嘛不寒掺](https://github.com/xiaojieonly/Ehviewer_CN_SXJ/blob/BiLi_PC_Gamer/feedauthor/support.md)    
   Telegram群:https://t.me/+WyclP8pPlk-JfbwS    
   Telegram通知群:https://t.me/Ehviewer_xiaojieonly_channel    


## [2023年日志-时间过的好快](https://github.com/xiaojieonly/Ehviewer_CN_SXJ/blob/BiLi_PC_Gamer/feedauthor/year2023-boom.md)  
## [2022年日志-成长](https://github.com/xiaojieonly/Ehviewer_CN_SXJ/blob/BiLi_PC_Gamer/feedauthor/year2022-growing-up.md)  
## [2021年日志-艰难起步](https://github.com/xiaojieonly/Ehviewer_CN_SXJ/blob/BiLi_PC_Gamer/feedauthor/year2021-step-begin.md)  
## [2020年日志-爱与痛的开始](https://github.com/xiaojieonly/Ehviewer_CN_SXJ/blob/BiLi_PC_Gamer/feedauthor/year2020-love-begin.md)

# EhViewer

![Icon](art/launcher_icon-web.png)

这是一个 E-Hentai Android 平台的浏览器。

An E-Hentai Application for Android.


# Screenshot

![screenshot-01](art/screenshot-01.png)


# Build

Windows

    > git clone https://github.com/xiaojieonly/Ehviewer_CN_SXJ.git
    > cd EhViewer
    > gradlew app:assembleDebug

Linux

    $ git clone https://github.com/xiaojieonly/Ehviewer_CN_SXJ.git
    $ cd EhViewer
    $ ./gradlew app:assembleDebug

生成的 apk 文件在 app\build\outputs\apk 目录下

The apk is in app\build\outputs\apk


# Download

[下载](https://github.com/shuaixiaojie/Ehviewer_CN_SXJ/releases)

# Thanks

感谢Ehviewer奠基人[Hippo/seven332](https://github.com/seven332)    
Thanks to [Hippo/seven332](https://github.com/seven332), the founder of Ehviewer    

本项目受到了诸多开源项目的帮助  
This project has received help from many open source projects  

这是部分库
Here is the libraries  
- [AOSP](http://source.android.com/)
- [android-advancedrecyclerview](https://github.com/h6ah4i/android-advancedrecyclerview)
- [Apache Commons Lang](https://commons.apache.org/proper/commons-lang/)
- [apng](http://apng.sourceforge.net/)
- [giflib](http://giflib.sourceforge.net)
- [greenDAO](https://github.com/greenrobot/greenDAO)
- [jsoup](https://github.com/jhy/jsoup)
- [libjpeg-turbo](http://libjpeg-turbo.virtualgl.org/)
- [libpng](http://www.libpng.org/pub/png/libpng.html)
- [okhttp](https://github.com/square/okhttp)
- [roaster](https://github.com/forge/roaster)
- [ShowcaseView](https://github.com/amlcurran/ShowcaseView)
- [Slabo](https://github.com/TiroTypeworks/Slabo)
- [TagSoup](http://home.ccil.org/~cowan/tagsoup/)
